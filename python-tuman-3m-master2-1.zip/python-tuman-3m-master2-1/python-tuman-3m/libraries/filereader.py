import scipy


def to_float(array):
    return list(map(float, array))


def interpolateDataFromFile(file):
    lines = [" ".join(line.strip().split()).split(" ") for line in file]
    lines = list(map(to_float, lines))
    array_x = []
    array_y = []
    for line in lines:
        array_x.append(line[0])
        array_y.append(line[1])

    return scipy.interpolate.make_interp_spline(array_x, array_y, k=3)

def interpolateFromFile(file):
    lines = [" ".join(line.strip().split()).split(" ") for line in file]
    lines = list(map(to_float, lines))
    array_x = []
    array_y = []
    for line in lines:
        array_x.append(line[0])
        array_y.append(line[1])

    return scipy.interpolate.interp1d(array_x, array_y)
