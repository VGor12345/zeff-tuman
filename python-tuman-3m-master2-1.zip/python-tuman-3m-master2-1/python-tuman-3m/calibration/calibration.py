import scipy.interpolate
import scipy.integrate as integrate


def to_float(array):
    return list(map(float, array))


def interpolateDataFromFile(file):
    lines = [" ".join(line.strip().split()).split(" ") for line in file]
    lines = list(map(to_float, lines))
    array_x = []
    array_y = []
    for line in lines:
        array_x.append(12395 / line[0])
        array_y.append(line[1])
    return scipy.interpolate.interp1d(array_x, array_y, fill_value='extrapolate')


with open('FPU-function.txt', 'r') as file:
    fpu = interpolateDataFromFile(file)

with open('15microns.txt', 'r') as file:
    Be15 = interpolateDataFromFile(file)

with open('27microns.txt', 'r') as file:
    Be27 = interpolateDataFromFile(file)

with open('50microns.txt', 'r') as file:
    Be50 = interpolateDataFromFile(file)

with open('80microns.txt', 'r') as file:
    Be80 = interpolateDataFromFile(file)

with open('127microns.txt', 'r') as file:
    Be127 = interpolateDataFromFile(file)

calibrate15 = lambda x: fpu(x) * Be15(x)
calibrate27 = lambda x: fpu(x) * Be27(x)
calibrate50 = lambda x: fpu(x) * Be50(x)
calibrate80 = lambda x: fpu(x) * Be80(x)
calibrate127 = lambda x: fpu(x) * Be127(x)
print(integrate.quad(calibrate15, 0, 120))
print(integrate.quad(calibrate27, 0, 120))
print(integrate.quad(calibrate50, 0, 120))
print(integrate.quad(calibrate80, 0, 120))
print(integrate.quad(calibrate127, 0, 120))
