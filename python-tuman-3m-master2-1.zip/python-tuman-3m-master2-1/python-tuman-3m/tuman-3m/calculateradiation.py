import math
import scipy
import scipy.integrate as integrate
import matplotlib.pyplot as plt
#import libraries.filereader as filereader
import filereader1 as filereader
#import filereader1


with open('exp5.txt', 'r') as file:
    fileData = filereader.interpolateFromFile(file)
    neCentral = lambda x: (fileData(x) * 2.1 * pow(10, 13)) #* 2.1  *1.5 

temepratureX = [
    -22.5,
    -14.8,
    -10.4,
    -7.3,
    0,
    7.3,
    10.4,
    14.8,
    22.5
]
temepratureY = [60,
                290.97919,
                341.11414,
                442.24939,
                454.76642,
                442.24939,
                341.11414,
                290.97919,
                60
                ]
temperature = scipy.interpolate.interp1d(temepratureX, temepratureY)

def calculateRadiation(t):   #t=30
    # данные для апроксимации электронной температуры
    TeCentral = 454
    TePeriphery = 60

    # данные для апроксимации электронной концентрации
    nePeriphery = 0

    constant_formula = 1.9 * 10 ** -28  # константа перед интегралом
    gaunt_factor = 2
    omega = 1.854e-3 #0.00132  # телесный угол 0.0017950198753548358
    tg_alpha_2 = 2.437e-2 #tg alpha/2  0.023908523908523906 

    radiusA = 22  # малый радиус такомака туман
    distanceFromDiagnosticsToTokomak = 26  # раастояние от диагностики до токамака

    # объём
    # радиус окружности на столбе токамака, куда смотрит диагностика
    #volume = math.pi * 4.2 ** 2 / (3 * (radiusA + radiusA + distanceFromDiagnosticsToTokomak) ** 2) * (
    #volume = math.pi * 0.115 ** 2 / (3 * (radiusA + radiusA + distanceFromDiagnosticsToTokomak) ** 2) * (
    #        (radiusA + radiusA + distanceFromDiagnosticsToTokomak) ** 3 - distanceFromDiagnosticsToTokomak ** 3)
    #!!volume = lambda x: math.pi * x * () * tg_alpha_2 ** 2 / 3
    #volume0 = math.pi * 2 * radiusA * (distanceFromDiagnosticsToTokomak ** 2 + distanceFromDiagnosticsToTokomak * (
    #    distanceFromDiagnosticsToTokomak + 2 * radiusA) + (distanceFromDiagnosticsToTokomak + 2 * radiusA) ** 2) * tg_alpha_2 ** 2 / 3 
    #считаем, что угол маленький, поэтому объем считаем сразу, без ввода в интеграл 
    s1 = math.pi * 0.464 ** 2 #R''=0.464 -- радиус у начала столба, 146 мм
    s2 = math.pi * 1.526 ** 2 #R=1.526 -- радиус у самого конца столба
    #sm = math.pi * 2 ** 2
    volumes = 2 * radiusA * (s1 + s2 + math.sqrt(s1 * s2)) / 3
    #print(s1,s2,sm)
    #print(volumes)
    #print(volume,volumes)
    # аппроксимация электронной концентрации
    density = lambda x: (neCentral(t) - nePeriphery) * ((1 - (x / radiusA) ** 2) ** 2) + nePeriphery

    # аппроксимация электронной температуры

    # temperature = lambda x: (TeCentral - TePeriphery) * ((1 - (x / radiusA) ** 2) ** 2) + TePeriphery

    # граници интегрирования по лямда
    lambda1 = 0.9
    lambdaMax = 6200 / TeCentral

    f = lambda R, L: (
            constant_formula * gaunt_factor * density(R) * density(R) / (math.sqrt(temperature(R)) * L ** 2) *
            math.exp(-12395 / (L * temperature(R))) * omega * volumes )
    #result = integrate.dblquad(f,-1 * radiusA, radiusA, gfun=, hfun, lambda1, lambdaMax, )
    result = integrate.dblquad(f, lambda1, lambdaMax, -1 * radiusA, radiusA)
    #print(result)
    
    # smallRadiusArray = list(range(-radiusA - 1, radiusA + 1))

    # densityArray = list(map(density, smallRadiusArray))
    # plt.subplot(121)
    # plt.grid(True)
    # plt.plot(smallRadiusArray, densityArray)
    #
    # temperatureArray = list(map(temperature, smallRadiusArray))
    # plt.subplot(122)
    # plt.grid(True)
    # plt.plot(smallRadiusArray, temperatureArray)
    #
    # plt.savefig('profiles_chart.png')
    # plt.show()

    return result[0]

