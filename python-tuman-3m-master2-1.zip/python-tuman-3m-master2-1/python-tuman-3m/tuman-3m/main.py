#!Shot: 24032706
# !Signal: HF_sxr: Averaged(200)
# !Calibrations applied (if any)
# !Program version 442; Export date: 26.04.2024 (13:25:51)

import matplotlib.pyplot as plt
import numpy as np
import calculateradiation as radiation
#import libraries.filereader as filereader
import filereader1 as filereader
import scipy
#import scipy.integrate as integrate


def arith_mean(f, buffer_size=10):
    # Creating buffer
    if not hasattr(arith_mean, "buffer"):
        arith_mean.buffer = [f] * buffer_size

    # Move buffer to actually values ( [0, 1, 2, 3] -> [1, 2, 3, 4] )
    arith_mean.buffer = arith_mean.buffer[1:]
    arith_mean.buffer.append(f)

    # Calculation arithmetic mean
    mean = 0
    for e in arith_mean.buffer: mean += e
    mean /= len(arith_mean.buffer)

    return mean


with open('exp2.txt', 'r') as file:
    fileData = filereader.interpolateFromFile(file)
    data = lambda x: fileData(x) / 1.9

X_ = np.linspace(40, 92, 50) #50
a = 0.113
normalize = lambda x: (data(x) - data(8))
to_V_from_mV = lambda x: normalize(x) / 1000 
Zeff = lambda x: a * to_V_from_mV(x) / (radiation.calculateRadiation(x)) #Zeff = lambda x: to_V_from_mV(x) / (radiation.calculateRadiation(x) * 0.1)

Y_ = [Zeff(x) for x in X_]
plt.plot(X_, Y_)
plt.title("Plot Smooth Curve Using the scipy.interpolate.interp1d Class")
plt.xlabel("time, ms")
plt.ylabel("Y")

plt.savefig('Zeff.png')
plt.show()
